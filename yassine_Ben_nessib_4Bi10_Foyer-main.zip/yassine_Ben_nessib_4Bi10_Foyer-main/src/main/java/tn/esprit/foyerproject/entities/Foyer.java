package tn.esprit.foyerproject.entities;
import tn.esprit.foyer_bi.entities.Universite;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Foyer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long idFoyer;
    private String nomFoyer;
    private long capaciteFoyer;

    @OneToMany
    List<Bloc> blocs ;

    @OneToOne(mappedBy = "foyer")
    Universite universite;
}
