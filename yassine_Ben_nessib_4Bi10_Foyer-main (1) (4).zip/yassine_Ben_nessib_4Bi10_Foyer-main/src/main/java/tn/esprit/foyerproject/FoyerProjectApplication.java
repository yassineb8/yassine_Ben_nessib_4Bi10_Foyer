package tn.esprit.foyerproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoyerProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoyerProjectApplication.class, args);
	}

}
