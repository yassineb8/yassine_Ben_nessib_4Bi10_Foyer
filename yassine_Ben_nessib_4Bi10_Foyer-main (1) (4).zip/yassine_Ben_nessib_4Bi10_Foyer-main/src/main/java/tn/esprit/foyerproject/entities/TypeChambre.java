package tn.esprit.foyerproject.entities;

public enum TypeChambre {
    SIMPLE,DOUBLE,TRIPLE
}
